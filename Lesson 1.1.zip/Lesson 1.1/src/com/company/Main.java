package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("Hello world!");

        int myNumber = 54;
        System.out.println(myNumber);

        myNumber = -9;

        int a;

        a = 7;

        System.out.println(myNumber);
        System.out.println("результат сложения: " + (a + myNumber));

        float var = 15.678f;
        double var2 = 15.6;
        char character = '$';
        boolean isSunny = true;
        boolean isSmaller = myNumber < a;
        boolean isEqual = a == myNumber;

        System.out.println(isSunny);
        System.out.println(!isEqual);
    }
}
